<?php echo date("D M d Y H:i:s");  exit;?>

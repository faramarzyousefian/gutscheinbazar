<?php
/******************************************
* @Created on March, 2011 * @Package: Ndotdeals unlimited v2.2 
* @Author: NDOT
* @URL : http://www.ndot.in
********************************************/
?>
<?php 
session_start();
require_once ('dboperations.php');
require_once ('docroot.php'); 
require_once ('config.php'); 
require_once ('functions.php');
require_once ('functions_theme.php');
require_once ('fns.php');
require_once ('paginator.class.php');
require_once (DOCUMENT_ROOT.'/system/plugins/common.php'); 
require_once (DOCUMENT_ROOT.'/themes/_base_theme/email/email_variables.php'); 
?>

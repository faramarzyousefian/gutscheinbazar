<?php
define("DOCUMENT_ROOT",$_SERVER['DOCUMENT_ROOT']);
	ob_clean();
	ob_start();
	require("twitteroauth.php");
	require 'config/twconfig.php';
	//require 'config/functions.php';
	session_start();
	
	//print_r($_SESSION);exit;
	if (!empty($_GET['oauth_verifier']) && !empty($_SESSION['oauth_token']) && !empty($_SESSION['oauth_token_secret'])) 
	{
		// We've got everything we need
		$twitteroauth = new TwitterOAuth(YOUR_CONSUMER_KEY, YOUR_CONSUMER_SECRET, $_SESSION['oauth_token'], $_SESSION['oauth_token_secret']);
		// Let's request the access token
		$access_token = $twitteroauth->getAccessToken();
		// Save it in a session var
		$_SESSION['oauth_token'] = $access_token['oauth_token'];
		$_SESSION['oauth_token_secret'] = $access_token['oauth_token_secret'];
		// Let's get the user's info
		$user_info = $twitteroauth->get('account/verify_credentials');
		//print_r($access_token);exit;
		if (isset($user_info->error)) 
		{
			  
			header('Location: login-twitter.php');
		} 
		else
		{
			$twitter_otoken = $_SESSION['oauth_token'];
			$twitter_otoken_secret = $_SESSION['oauth_token_secret'];
			$email='';
			$uid = $user_info->id;
			$username = $user_info->name;
			$firstname = $user_info->name;
			$profile_image = $user_info->profile_image_url_https;
			
			if($_SESSION["userrole"] == 1)
			{ 

					updateTWuser($_SESSION['oauth_token'],$_SESSION['oauth_token_secret'],$uid ,$firstname); 				
					url_redirect(DOCROOT."admin/social-media-account/");	
			} 
			
			easyRegister($username,$firstname,"","",$profile_image,2);
			header("Location:".DOCROOT."profile.html");
		
		}
	} 
	else
	{ 
		sheader('Location: login-twitter.php');
	}
?>

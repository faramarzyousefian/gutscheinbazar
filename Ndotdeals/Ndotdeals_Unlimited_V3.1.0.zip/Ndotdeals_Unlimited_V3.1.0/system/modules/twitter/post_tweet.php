<?php
/**
* post_tweet.php
* Example of posting a tweet with OAuth
* Latest copy of this code: 
* http://140dev.com/twitter-api-programming-tutorials/hello-twitter-oauth-php/
* @author Adam Green <140dev@gmail.com>
* @license GNU Public License
*/

/* returns the shortened url */
function get_bitly_short_url($url,$login,$appkey,$format='txt') {
  $connectURL = 'http://api.bit.ly/v3/shorten?login='.$login.'&apiKey='.$appkey.'&uri='.urlencode($url).'&format='.$format;
  return curl_get_result($connectURL);
}
/* returns a result form url */
function curl_get_result($url) {
  $ch = curl_init();
  curl_setopt($ch,CURLOPT_URL,$url);
  curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);
  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
  $data = curl_exec($ch);
  curl_close($ch);
  return $data;
}

//print_r($share_link);
/* get the short url */
$short_url = get_bitly_short_url($Status_Message,'kannansp','R_2c7f253e911e440093c97ca3788ebff2');			

$tweet_text = "The new deal has been posted with best offer. Hurry up!!! ".$short_url;

//$tweet_text = $Status_Message;
//print "Posting...\n";
$result = post_tweet($tweet_text);
//print "Response code: " . $result . "\n";

function post_tweet($tweet_text) {
//echo $tweet_text;exit;
  // Use Matt Harris' OAuth library to make the connection
  // This lives at: https://github.com/themattharris/tmhOAuth
  require_once('tmhOAuth.php');
  require 'config/twconfig.php';    
  //echo USER_TOKEN;exit;
  // Set the authorization values
  // In keeping with the OAuth tradition of maximum confusion, 
  // the names of some of these values are different from the Twitter Dev interface
  // user_token is called Access Token on the Dev site
  // user_secret is called Access Token Secret on the Dev site
  // The values here have asterisks to hide the true contents 
  // You need to use the actual values from your Twitter app
 
  $connection = new tmhOAuth(array(
    'consumer_key' => YOUR_CONSUMER_KEY,
    'consumer_secret' => YOUR_CONSUMER_SECRET,
    'user_token' => USER_TOKEN,
    'user_secret' => USER_SECRET,
  )); 
  
  // Make the API call
  $connection->request('POST', 
    $connection->url('1/statuses/update'), 
    array('status' => $tweet_text));
  
  return $connection->response['code'];
}
?>

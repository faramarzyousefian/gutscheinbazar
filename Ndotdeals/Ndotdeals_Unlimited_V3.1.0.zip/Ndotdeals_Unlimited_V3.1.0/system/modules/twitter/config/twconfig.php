<?php
define("DOCUMENT_ROOT",$_SERVER['DOCUMENT_ROOT']);
require_once(DOCUMENT_ROOT."/system/includes/dboperations.php");
require_once(DOCUMENT_ROOT."/system/includes/docroot.php");
require_once(DOCUMENT_ROOT."/system/includes/functions.php");

$all_category_id = mysql_query("select * from general_settings ");
	while($init = mysql_fetch_array($all_category_id))
	{
		$apikey = $init["tw_apikey"];
		$secretkey = $init["tw_secretkey"];
	}
define('YOUR_CONSUMER_KEY', $apikey);
define('YOUR_CONSUMER_SECRET', $secretkey);

$usertoken = mysql_query("SELECT * FROM social_account where type = 2");
	while($usertok = mysql_fetch_array($usertoken))
	{ 
		$accesstoken = $usertok["access_token"];
		$tokensecretkey = $usertok["access_token_secret"];
	}

define('USER_TOKEN', $accesstoken);
define('USER_SECRET', $tokensecretkey);
 
//DQ9HRyRvo9ajkAVWixQATr5wNuHj7FKmMPB1KvpGWI

?>

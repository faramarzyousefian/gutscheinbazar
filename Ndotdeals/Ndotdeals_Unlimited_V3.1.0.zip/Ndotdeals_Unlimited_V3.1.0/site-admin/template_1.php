<div class="fl login_cont clr">
<?php
include(DOCUMENT_ROOT."/".$current_file); ?>
</div>


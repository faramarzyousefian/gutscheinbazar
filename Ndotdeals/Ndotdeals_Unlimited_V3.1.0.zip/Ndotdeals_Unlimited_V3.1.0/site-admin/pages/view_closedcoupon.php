<?php session_start();
is_login(DOCROOT."admin/login/"); //checking whether admin logged in or not.
getclosedcoopondetails();
?>


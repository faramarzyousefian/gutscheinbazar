<?php session_start();
is_login(DOCROOT."admin/login/"); //checking whether admin logged in or not.

?>

<div class="deals_desc1">      
<a href="http://support.ndot.in/ticket/login" title="ticket" target="_blank">Click here</a> to submit ticket to get NDOT Support...
</div>


<div class="login_footer ">
      <div class="login_footer_inner">
     
      		<p> <?php echo $admin_language['copyright']; ?> &copy; <?php echo date("Y"); ?> <?php echo SITE_NAME;?>.<?php echo $admin_language['allrightreserved']; ?> .</p>
      </div>
</div>


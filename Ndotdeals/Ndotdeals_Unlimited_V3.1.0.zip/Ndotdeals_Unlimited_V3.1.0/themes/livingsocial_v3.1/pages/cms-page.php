<?php 
/********************************************
 * @Created on March, 2011 * @Package: Ndotdeals unlimited v2.2
 * @Author: NDOT
 * @URL : http://www.NDOT.in
 ********************************************/
?>

<div class="work_bottom">
  <p> <?php echo nl2br(html_entity_decode($page_desc));?> </p>
</div>

<?php
/******************************************
* @Created on March, 2011 * @Package: Ndotdeals unlimited v2.2
* @Author: NDOT
* @URL : http://www.NDOT.in
********************************************/
?>

<?php
//get the hot deals
getcoupons('P','',$_SESSION['defaultcityId']);

?>

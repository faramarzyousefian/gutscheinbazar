<?php
/******************************************
* @Created on March, 2011 * @Package: Ndotdeals unlimited v2.2
* @Author: NDOT
* @URL : http://www.NDOT.in
********************************************/
?>

<?php /*?><div class="brad">
  <ul>
    <li><a href="/" title="Home"><?php echo $language['home']; ?> </a></li>
    <li><span class="right_arrow"></span></li>
    <li><a href="javascript:;" title="How It Works"><?php echo $language['how_it_works']; ?></a></li>
  </ul>
</div>
<h1><?php echo $page_title; ?></h1><?php */?>
<div class="banner">
  <div class="get_it">
    <h2><?php echo $language['getit']; ?></h2>
    <p><?php echo $language['how1']; ?> </p>
    <img style="margin:0 0 0 18px;" src="<?php echo DOCROOT;?>themes/<?php echo CURRENT_THEME;?>/images/get_img.png" /> </div>
  <div class="get_it">
    <h3><?php echo $language['shareit']; ?></h3>
    <p><?php echo $language['how2']; ?></p>
    <img style="margin:0 0 0 38px;" src="<?php echo DOCROOT;?>themes/<?php echo CURRENT_THEME;?>/images/shere_it.png" /> </div>
  <div class="get_it">
    <h4><?php echo $language['enjoyit']; ?></h4>
    <p><?php echo $language['how3']; ?></p>
    <img style="margin:0 0 0 18px;" src="<?php echo DOCROOT;?>themes/<?php echo CURRENT_THEME;?>/images/enjoy.png" /> </div>
</div>
<?php /*?><div class="work_bottom">
                                <p><?php echo $language['how4']; ?></p>
			        <p><?php echo $language['how5']; ?></p>
                                <p><?php echo $language['how6']; ?></p>
			</div><?php */?>

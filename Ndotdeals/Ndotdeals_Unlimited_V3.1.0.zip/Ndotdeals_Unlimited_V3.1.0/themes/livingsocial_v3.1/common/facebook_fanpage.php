<!-- facebook fan page -->

<div class="fl  borderF2F clr">
  <div class="great_deals">
    <div class="great_top">
      <h1>Facebook connect</h1>
    </div>
    <div class="great_center">
       <iframe src="http://www.facebook.com/plugins/likebox.php?href=<?php echo FANPAGE_URL; ?>&amp;width=230&amp;colorscheme=light&amp;show_faces=true&amp;stream=false&amp;header=false&amp;height=310" scrolling="no" frameborder="0" style="border:none; overflow:hidden; width:230px; height:310px; margin:10px 0 0 6px;" allowTransparency="true"></iframe>
    </div>
    <div class="great_bottom"> </div>
  </div>
</div>

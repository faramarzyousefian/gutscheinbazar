<div class=" fl clr borderF2F ">
  <div class="refere_friend fl">
    <div class="great_top">
      <h1><?php echo $language['refer_friend']; ?></h1>
    </div>
    <?php //echo $language['earn'].CURRENCY.REF_AMOUNT; ?>
    <div class="request_middle fl"> <a class="refer" href="<?php echo DOCROOT;?>referral.html">EARN <?php echo CURRENCY.REF_AMOUNT; ?></a> </div>
  </div>
</div>

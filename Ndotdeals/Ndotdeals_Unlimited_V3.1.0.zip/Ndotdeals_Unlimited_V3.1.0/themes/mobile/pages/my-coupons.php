<?php
is_login(DOCROOT."login.html"); //checking whether user logged in or not. 
//include("profile_submenu.php"); ?>
<?php /* <h1><?php echo $page_title; ?></h1> */ ?>

<div class="mobile_content">
      <div class="content_high">

	<?php 
	report("mycoupon");
	?>

</div>
</div>

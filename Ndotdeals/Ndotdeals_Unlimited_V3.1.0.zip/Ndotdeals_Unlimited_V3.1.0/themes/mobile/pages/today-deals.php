<h1><?php echo $page_title; ?></h1>

<?php 

//get the hot deals
getcoupons('T','',$default_city_id);

?>

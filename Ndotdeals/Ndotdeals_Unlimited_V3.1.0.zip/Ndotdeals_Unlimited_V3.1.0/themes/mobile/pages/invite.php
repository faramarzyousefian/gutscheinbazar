<?php
/******************************************
* @Created on March, 2011 * @Package: Ndotdeals unlimited v2.2
* @Author: NDOT
* @URL : http://www.NDOT.in
********************************************/
?>

<ul>
<li><a href="/" title="<?php echo $language['home']; ?>"><?php echo $language['home']; ?> </a></li>
<li><span class="right_arrow"></span></li>
<li><a href="javascript:;" title="<?php echo $language['past_deals']; ?>"><?php echo $language['past_deals']; ?></a></li>    
</ul>

<h1><?php echo $page_title; ?></h1>

<div class="work_bottom login_area">
<?php include(DOCUMENT_ROOT.'/system/modules/OpenInviter/index.php')?>
</div>
<div class="great_deals mb20 fl clr">
        <div class="great_top">

	        <h1>API Documentation</h1>
        </div>
        <div class="great_center">
                <div class="width227 fl clr borderF2F ml10">
                
                        <a href="/api-documentation.html" title="API Resources" style="color:#000;">
                                <div class="right_top">
                                </div>
                                 <div class="left_img">
                                 <img class="fl" src="<?php echo DOCROOT;?>themes/<?php echo CURRENT_THEME; ?>/images/doc_api.png" />
                                 </div>                         
                                <div class="right_text">
                                <h1>API Resources</h1>
                                All API resources available in <?php echo SITE_NAME; ?>  </div>
                        </a>
                        <a href="/api-deals.html" title="Deals" style="color:#000;">
                                <div class="right_top">
                                </div>
                                 <div class="left_img">
                                 <img class="fl" src="<?php echo DOCROOT;?>themes/<?php echo CURRENT_THEME; ?>/images/doc_api.png" />
                                 </div>                         
                                <div class="right_text">
                                <h1>Deals</h1>
                                All APIs available in <?php echo SITE_NAME; ?>  </div>
                        </a>
                        <a href="/api-errors.html" title="API Errors" style="color:#000;">
                                <div class="right_top">
                                </div>
                                 <div class="left_img">
                                 <img class="fl" src="<?php echo DOCROOT;?>themes/<?php echo CURRENT_THEME; ?>/images/doc_api.png" />
                                 </div>                         
                                <div class="right_text">
                                <h1>API Errors</h1>
                                All API Errors responses
                                </div>
                        </a>
      
                </div>
        </div>
        <div class="great_bottom"></div>
</div>

<?php 
/********************************************
 * @Created on March, 2011 * @Package: Ndotdeals unlimited v2.2
 * @Author: NDOT
 * @URL : http://www.NDOT.in
 ********************************************/
?>
<div class="content_right1 mb-10">
  <div class="great_deals">
	<div class="great_top">
		<h1>Facebook Connect</h1>
	</div>
	<div class="great_center">

	<div class="contact_right fl clr">
		<p>
			<?php echo $language["already_have_account"]; ?><br /><?php echo $language["use_it"]; ?>
		</p>
		<a href="<?php echo DOCROOT;?>system/modules/facebook/facebook-connect.php" title="facebook connect" class="bg_facebook fl clr mt15 ml10"></a>
	</div>			
	</div>   
	<div class="great_bottom"></div>
 </div>
</div>
   


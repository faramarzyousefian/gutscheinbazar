<!-- facebook fan page -->
<div class="width240 fl  borderF2F clr mb20">
          <div class="great_deals mt10">
	          <div class="great_top">
              	<h1><?php echo $language["find_us_on_facebook"];?></h1>
              </div>
			<div class="great_center">
			   <?php fanpage(FANPAGE_URL); ?>
			</div>
	          
	          <div class="great_bottom"></div>
      
      	  </div>

</div>

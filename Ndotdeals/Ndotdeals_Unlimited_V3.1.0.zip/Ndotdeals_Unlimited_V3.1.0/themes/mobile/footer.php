<?php
$url_arr = explode('/',$_SERVER['REQUEST_URI']);

if($url_arr[1] == 'today-deals.html')
{
        $today_deals = 'active';
}
else if($url_arr[1] == 'hot-deals.html')
{
        $hot_deals = 'active';
}
else if($url_arr[1] == 'past-deals.html' || $url_arr[2] == 'past')
{
        $past_deals = 'active';
}
else if($url_arr[1] == 'how-it-works.html')
{
        $how_it_works = 'active';
}
else if($url_arr[1] == 'contactus.html')
{
        $contactus = 'active';
}
else
{
        $home = 'active';
}
?>
 <footer>
        <ul>
            <li><a href="<?php echo DOCROOT;?>" title="<?php echo ucfirst($language['today']); ?>"><?php echo ucfirst($language["today"]); ?></a></li>
            <li><a href="<?php echo DOCROOT;?>hot-deals.html" title="<?php echo ucfirst($language['hot']); ?>"><?php echo ucfirst($language["hot"]); ?></a></li>
            <li><a href="<?php echo DOCROOT;?>past-deals.html" title="<?php echo ucfirst($language['past_deals']); ?>"><?php echo ucfirst($language["past_deals"]); ?></a></li>
            <li><a href="<?php echo DOCROOT;?>contactus.html" title="<?php echo ucfirst($language['contact_us']); ?>"><?php echo ucfirst($language["contact_us"]); ?></a></li>
        </ul>
 </footer>

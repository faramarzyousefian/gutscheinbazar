<?php
/******************************************
* @Created on March, 2011 * @Package: Ndotdeals unlimited v2.2
* @Author: NDOT
* @URL : http://www.NDOT.in
********************************************/
?>

<ul>
<li><a href="/" title="<?php echo $language['home']; ?>"><?php echo $language['home']; ?> </a></li>
<li><span class="right_arrow"></span></li>
<li><a href="javascript:;" title="<?php echo $language['how_it_works']; ?>"><?php echo $language['how_it_works']; ?></a></li>    
</ul>

<h1><?php  echo  $language["how_grouponclone_works"];?></h1>
                        
                        <div class="banner">
	<div class="get_it">
		<h2><?php echo $language['getit']; ?></h2>
		<p><?php echo $language['how1']; ?> </p>
		<img style="margin:0 0 0 18px;" src="<?php echo DOCROOT;?>themes/<?php echo CURRENT_THEME;?>/images/get_img.png" />
	</div>
	<div class="get_it">
		<h3><?php echo $language['shareit']; ?></h3>
		<p><?php echo $language['how2']; ?></p>
		<img style="margin:0 0 0 38px;" src="<?php echo DOCROOT;?>themes/<?php echo CURRENT_THEME;?>/images/share_img.png" />
	</div>
	<div class="get_it">
		<h4><?php echo $language['enjoyit']; ?></h4>
		<p><?php echo $language['how3']; ?></p>
		<img src="<?php echo DOCROOT;?>themes/<?php echo CURRENT_THEME;?>/images/enjoy_img.png" />
	</div>
</div>
                        
                        <?php /*?><div class="work_bottom">
                                <p><?php echo $language['how4']; ?></p>
			        <p><?php echo $language['how5']; ?></p>
                                <p><?php echo $language['how6']; ?></p>
			</div><?php */?>

<div class="great_deals mb20 fl clr">
        <div class="great_top">

	        <h1>API Resources</h1>
        </div>
        <div class="great_center">
                <div class="width227 fl clr borderF2F ml10 top1">
                                    <a href="/api-terms-of-use.html" title="Terms of Use" style="color:#000;">
                                <div class="right_top">
                                </div>
                                <div class="left_img">
                                <img class="fl" src="<?php echo DOCROOT;?>themes/<?php echo CURRENT_THEME; ?>/images/terms.png" alt="terms" border="0" />
                                </div>                      
                                <div class="right_text">
                                <h1>Terms of Use</h1>
                                Legally binding fine print.
                                </div>
                        </a>
                        <a href="/api-branding-requirements.html" title="Branding Requirements" style="color:#000;">
                                <div class="right_top">
                                </div>
                                <div class="left_img">
                                <img class="fl" src="<?php echo DOCROOT;?>themes/<?php echo CURRENT_THEME; ?>/images/doc_api.png" />
                                </div>                       
                                <div class="right_text">
                                <h1>Branding Requirements</h1>
                                Read before you start coding.
                                </div>
                        </a>
                        <a href="/api-documentation.html" title="API Documentation" style="color:#000;">
                                <div class="right_top">
                                </div>
                                 <div class="left_img">
                                 <img class="fl" src="<?php echo DOCROOT;?>themes/<?php echo CURRENT_THEME; ?>/images/doc_api.png" />
                                 </div>                         
                                <div class="right_text">
                                <h1>API Documentation</h1>
                                Help docs for API
                                </div>
                        </a>
      
                </div>
        </div>
        <div class="great_bottom"></div>
</div>

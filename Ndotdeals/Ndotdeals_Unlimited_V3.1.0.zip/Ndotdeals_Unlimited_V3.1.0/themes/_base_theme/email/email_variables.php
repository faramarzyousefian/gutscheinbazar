<?php
/******************************************
* @Created on March, 2011 * @Package: Ndotdeals unlimited v2.2 
* @Author: NDOT
* @URL : http://www.ndot.in
********************************************/
?>
<?php
$email_variables = array(
	"registration_subject" => "Your ".SITE_NAME." Registration has been Completed",
	"registration_description" => "<div style='margin-left:30px;'>Your ".SITE_NAME." Registration has been Completed Successfully. 
	 Your ".SITE_NAME.",<br /><br /> <strong>User Name: </strong> USERNAME <br /> <strong> Password: </strong> PASSWORD</div>",
	"forgotpass_subject" => "Your ".SITE_NAME." account password has been Changed",
	"forgotpass_description" => "<div style='margin-left:30px;'>Your ".SITE_NAME." user account password has been Changed. Your ".SITE_NAME." , <br /><br /> <strong>User Name:</strong> USERNAME <br /> <strong>Password:</strong> PASSWORD</div>",
	"transaction_onhold_subject" => APP_NAME." Order Status",
	"transaction_onhold_description" => "<div style='margin-left:30px;'>Thanks for your payment and its on Hold until the deal reaches minimum purchase.</div>",
	"transaction_emailsub" => "Your Purchased Coupon COUPONNAME offer has been Started",
	"transaction_emaildesc" => "<div style='margin-left:30px;'>Your Purchased Coupon COUPONNAME, offer has been Started. Your Coupon Validity Id is VALIDITYID. You can avail the offer in the below shop by providing this Validity Id before EXPIREDATE.<br/></div>",
	"transaction_gift_emailsub" => "You Got Coupon Gift from your Friend",
	"transaction_gift_emaildesc" => "<div style='margin-left:30px;'>You Got Coupon Gift from your Friend SENDERNAME. Your Gift Coupon COUPONNAME, offer has been Started. Your Coupon Validity Id is VALIDITYID. You can avail the offer in the below shop by providing this Validity Id before EXPIREDATE.<br/><br/></div>",
	"daily_email" => "If you prefer not to receive the daily email, you can always",
	"unsubscribe_click" => "unsubscribe by clicking here",
	"order_status" => APP_NAME." Order Status",
	"order_statusdesc" => "<div style='margin-left:30px;'>Your Purchased deal COUPONNAME Order Status</div>",
	"close_offer_subject" => "Your Coupon COUPONNAME offer has been Used",
	"close_offer_description" => "Your Coupon COUPONNAME offer has been Used for the Validy Id VALIDITYID.",
	"referral_amount_subject" => "Referral amount credited in your account",
	"referral_amount_credited" => "Referral amount of REFERRAL_AMOUNT has been credited in your account for a deal purchased by REFERED",
	"subscription_thankyou" => "Thank you for your subscription of ",
	"subscription_subject" => "Thank you for your subscription.",
	"unsubscribe_subject" => "Newletter subscription",
	"unsubscribe_message" => "We are sorry to hear you are leaving the newsletter subscription of,",
	"but_hope_you_will_visit"=> " but hope you will visit again soon.",
	"subscription_visit"  => SITE_NAME." For more information, ",
	"visit_us" => "Visit Us",

);
?>
